# Chrome Web Store Assets Specifications

## Icons
✓ Created and included:
- 16x16 - For favicon
- 32x32 - For Windows
- 48x48 - For display in extension management
- 128x128 - For Chrome Web Store

## Screenshots
Resolution: 1280x800 or 640x400
Format: PNG or JPEG
Max size: 2MB each

## Promotional Images
1. Small Promotional Tile
- Size: 440x280 pixels
- Format: PNG
- Background: Gradient from #2563EB to #3B82F6

2. Large Promotional Tile
- Size: 920x680 pixels
- Format: PNG
- Background: White with blue accents

3. Marquee Promotional Tile
- Size: 1400x560 pixels
- Format: PNG
- Background: Clean white with feature highlights

## Brand Colors
Primary: #2563EB (Blue)
Secondary: #10B981 (Green)
Background: #F9FAFB
Text: #1F2937
Accent: #3B82F6