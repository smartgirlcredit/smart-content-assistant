# Screenshot Descriptions

1. Main Interface (1280x800)
- Clean, modern interface showing the translation and summarization options
- Sample text in the input field
- Language selector dropdown visible
- Both translation and summary results displayed

2. Context Menu (1280x800)
- Browser showing a webpage with text selected
- Context menu open showing "Translate Selection" and "Summarize Selection" options
- Extension icon visible in toolbar

3. Translation in Action (1280x800)
- Split screen showing original text and translation
- Language selection dropdown open
- Loading animation visible

4. Summarization Result (1280x800)
- Long article visible in background
- Popup showing concise summary
- Word count and reduction percentage displayed

5. Language Support (1280x800)
- Settings page showing all supported languages
- Clean grid layout of language options
- Search/filter functionality visible

Promotional Images:

1. Small Tile (440x280)
- "Smart Content Assistant" text on gradient background
- Simple icon showing translation/summarization concept
- Clean, minimal design

2. Large Tile (920x680)
- Split screen showing translation and summarization
- Modern UI elements
- Chrome browser frame visible
- Professional color scheme

3. Marquee Promo (1400x560)
- Panoramic view of the extension in action
- Multiple language translations visible
- Professional typography
- Feature highlights