import React, { useState } from 'react';
import { Globe2, FileText } from 'lucide-react';
import { languages, type LanguageCode } from './utils/languages';
import { useTranslation } from './hooks/useTranslation';
import { useSummarization } from './hooks/useSummarization';
import { TranslationResult } from './components/TranslationResult';
import { SummaryResult } from './components/SummaryResult';

function App() {
  const [inputText, setInputText] = useState('');
  const [targetLanguage, setTargetLanguage] = useState<LanguageCode>('en');
  
  const { translate, isTranslating, translatedText } = useTranslation();
  const { summarize, isSummarizing, summary } = useSummarization();

  const isLoading = isTranslating || isSummarizing;

  const handleTranslate = () => translate(inputText, targetLanguage);
  const handleSummarize = () => summarize(inputText);

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="px-6 py-8">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-gray-900">Smart Content Assistant</h1>
              <p className="mt-2 text-gray-600">Translate and summarize text using AI-powered tools</p>
            </div>

            <div className="space-y-6">
              <div>
                <label htmlFor="content" className="block text-sm font-medium text-gray-700">
                  Enter your text
                </label>
                <textarea
                  id="content"
                  rows={4}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  placeholder="Type or paste your text here..."
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                />
              </div>

              <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
                <div className="flex items-center space-x-4">
                  <select
                    value={targetLanguage}
                    onChange={(e) => setTargetLanguage(e.target.value as LanguageCode)}
                    className="block w-40 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  >
                    {languages.map((lang) => (
                      <option key={lang.code} value={lang.code}>
                        {lang.name}
                      </option>
                    ))}
                  </select>
                  <button
                    onClick={handleTranslate}
                    disabled={!inputText || isLoading}
                    className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                  >
                    <Globe2 className="w-5 h-5 mr-2" />
                    Translate
                  </button>
                </div>
                <button
                  onClick={handleSummarize}
                  disabled={!inputText || isLoading}
                  className="flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <FileText className="w-5 h-5 mr-2" />
                  Summarize
                </button>
              </div>

              {isLoading && (
                <div className="flex justify-center py-4">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              )}

              <TranslationResult translatedText={translatedText} />
              <SummaryResult summary={summary} />

              <div className="mt-8 text-center text-sm text-gray-500">
                <p>This is a demo version of the Smart Content Assistant.</p>
                <p>In the actual Chrome extension, translation and summarization are powered by Chrome's built-in AI APIs.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;