import { useState } from 'react';
import { summarizeText } from '../utils/chrome-api';

export function useSummarization() {
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [summary, setSummary] = useState('');

  const summarize = async (text: string) => {
    try {
      setIsSummarizing(true);
      const result = await summarizeText(text);
      setSummary(result.summary);
    } catch (error) {
      console.error('Summarization error:', error);
    } finally {
      setIsSummarizing(false);
    }
  };

  return {
    summarize,
    isSummarizing,
    summary,
  };
}