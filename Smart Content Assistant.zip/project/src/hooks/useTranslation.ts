import { useState } from 'react';
import { translateText } from '../utils/chrome-api';
import type { LanguageCode } from '../utils/languages';

export function useTranslation() {
  const [isTranslating, setIsTranslating] = useState(false);
  const [translatedText, setTranslatedText] = useState('');

  const translate = async (text: string, targetLanguage: LanguageCode) => {
    try {
      setIsTranslating(true);
      const result = await translateText(text, targetLanguage);
      setTranslatedText(result.translatedText);
    } catch (error) {
      console.error('Translation error:', error);
    } finally {
      setIsTranslating(false);
    }
  };

  return {
    translate,
    isTranslating,
    translatedText,
  };
}