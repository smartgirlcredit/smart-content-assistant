/// <reference types="chrome"/>

// Background service worker to handle API calls
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'TRANSLATE') {
    chrome.i18n.translateText({
      text: request.text,
      targetLanguage: request.targetLanguage || 'en',
    }, (result) => {
      sendResponse({ translatedText: result.translatedText });
    });
    return true;
  }

  if (request.type === 'SUMMARIZE') {
    chrome.summarization.summarize({
      text: request.text,
      maxLength: request.maxLength || 150,
    }, (result) => {
      sendResponse({ summary: result.summary });
    });
    return true;
  }
});

// Ensure service worker stays active
chrome.runtime.onInstalled.addListener(() => {
  console.log('Extension installed');
});