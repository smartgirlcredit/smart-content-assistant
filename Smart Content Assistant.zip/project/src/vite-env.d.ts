/// <reference types="vite/client" />

// Chrome API type declarations
declare namespace chrome {
  export namespace i18n {
    export function translateText(
      options: { text: string; targetLanguage: string },
      callback: (result: { translatedText: string }) => void
    ): void;
  }

  export namespace summarization {
    export function summarize(
      options: { text: string; maxLength: number },
      callback: (result: { summary: string }) => void
    ): void;
  }
}