// Mock implementation of Chrome APIs for development
export const mockChrome = {
  runtime: {
    onMessage: {
      addListener: (callback: (request: any, sender: any, sendResponse: any) => void) => {
        window.addEventListener('message', (event) => {
          if (event.source === window) {
            callback(event.data, {}, (response: any) => {
              window.postMessage({ type: 'CHROME_RESPONSE', response }, '*');
            });
          }
        });
      },
      removeListener: () => {},
    },
    sendMessage: (message: any) => {
      return new Promise((resolve) => {
        const handleResponse = (event: MessageEvent) => {
          if (event.data.type === 'CHROME_RESPONSE') {
            window.removeEventListener('message', handleResponse);
            resolve(event.data.response);
          }
        };
        window.addEventListener('message', handleResponse);
        window.postMessage(message, '*');
      });
    },
  },
  i18n: {
    translateText: ({ text, targetLanguage }: { text: string; targetLanguage: string }, 
      callback: (result: { translatedText: string }) => void) => {
      // Simulate translation
      setTimeout(() => {
        callback({ translatedText: `[Translated] ${text}` });
      }, 1000);
    },
  },
  summarization: {
    summarize: ({ text, maxLength }: { text: string; maxLength: number },
      callback: (result: { summary: string }) => void) => {
      // Simulate summarization
      setTimeout(() => {
        const summary = text.split(' ').slice(0, 10).join(' ') + '...';
        callback({ summary });
      }, 1000);
    },
  },
};