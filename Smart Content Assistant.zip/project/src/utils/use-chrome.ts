import { useEffect, useCallback } from 'react';
import { mockChrome } from './chrome-api-mock';

// Use real Chrome APIs in extension environment, mock APIs in development
const chrome = typeof window !== 'undefined' && (window as any).chrome?.runtime
  ? (window as any).chrome
  : mockChrome;

export const useChromeMessage = (
  callback: (request: any, sender: any, sendResponse: any) => void
) => {
  useEffect(() => {
    chrome.runtime.onMessage.addListener(callback);
    return () => chrome.runtime.onMessage.removeListener(callback);
  }, [callback]);
};

export const sendChromeMessage = async (message: any) => {
  return chrome.runtime.sendMessage(message);
};

export const translateText = async (text: string, targetLanguage: string = 'en') => {
  return new Promise((resolve) => {
    chrome.i18n.translateText({ text, targetLanguage }, resolve);
  });
};

export const summarizeText = async (text: string, maxLength: number = 150) => {
  return new Promise((resolve) => {
    chrome.summarization.summarize({ text, maxLength }, resolve);
  });
};