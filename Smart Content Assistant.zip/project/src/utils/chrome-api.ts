import { mockChrome } from './chrome-api-mock';
import type { LanguageCode } from './languages';

const isExtension = !!(typeof chrome !== 'undefined' && chrome.runtime?.id);
const chromeAPI = isExtension ? chrome : mockChrome;

export const translateText = async (
  text: string,
  targetLanguage: LanguageCode
): Promise<{ translatedText: string }> => {
  return new Promise((resolve) => {
    chromeAPI.runtime.sendMessage({
      type: 'TRANSLATE',
      text,
      targetLanguage,
    }, resolve);
  });
};

export const summarizeText = async (
  text: string,
  maxLength: number = 150
): Promise<{ summary: string }> => {
  return new Promise((resolve) => {
    chromeAPI.runtime.sendMessage({
      type: 'SUMMARIZE',
      text,
      maxLength,
    }, resolve);
  });
};

export const getSelectedText = async (): Promise<string> => {
  if (!isExtension) return '';
  
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]?.id) {
        chrome.tabs.sendMessage(
          tabs[0].id,
          { type: 'GET_SELECTED_TEXT' },
          (response) => {
            resolve(response?.text || '');
          }
        );
      } else {
        resolve('');
      }
    });
  });
};