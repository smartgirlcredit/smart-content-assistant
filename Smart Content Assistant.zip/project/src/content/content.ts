/// <reference types="chrome"/>

let lastSelectedText = '';

// Handle text selection
document.addEventListener('mouseup', () => {
  const selectedText = window.getSelection()?.toString().trim();
  
  if (selectedText && selectedText !== lastSelectedText) {
    lastSelectedText = selectedText;
    chrome.runtime.sendMessage({
      type: 'TEXT_SELECTED',
      text: selectedText
    });
  }
});

// Handle messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'GET_SELECTED_TEXT') {
    sendResponse({ text: lastSelectedText });
  }
  return true;
});