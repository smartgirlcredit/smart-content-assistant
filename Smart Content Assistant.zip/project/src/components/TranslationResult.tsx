import React from 'react';

interface TranslationResultProps {
  translatedText: string;
}

export function TranslationResult({ translatedText }: TranslationResultProps) {
  if (!translatedText) return null;

  return (
    <div className="p-4 bg-blue-50 rounded-lg">
      <h2 className="text-sm font-semibold text-blue-800 mb-2">Translation:</h2>
      <p className="text-gray-800">{translatedText}</p>
    </div>
  );
}