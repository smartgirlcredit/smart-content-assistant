import React from 'react';

interface SummaryResultProps {
  summary: string;
}

export function SummaryResult({ summary }: SummaryResultProps) {
  if (!summary) return null;

  return (
    <div className="p-4 bg-green-50 rounded-lg">
      <h2 className="text-sm font-semibold text-green-800 mb-2">Summary:</h2>
      <p className="text-gray-800">{summary}</p>
    </div>
  );
}