# Smart Content Assistant

A Chrome extension that leverages Chrome's built-in AI APIs to translate and summarize content from any webpage.

## Features

- Text translation using Chrome's Translation API
- Content summarization using Chrome's Summarization API
- Real-time text selection processing
- Clean and intuitive user interface

## Installation

1. Clone this repository
2. Run `npm install` to install dependencies
3. Run `npm run build` to build the extension
4. Load the `dist` folder as an unpacked extension in Chrome

## Development

- `npm run dev` - Start development server
- `npm run build` - Build production version
- `npm run lint` - Run ESLint

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.